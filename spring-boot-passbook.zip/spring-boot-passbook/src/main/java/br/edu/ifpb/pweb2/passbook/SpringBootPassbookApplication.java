package br.edu.ifpb.pweb2.passbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPassbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPassbookApplication.class, args);
	}

}
