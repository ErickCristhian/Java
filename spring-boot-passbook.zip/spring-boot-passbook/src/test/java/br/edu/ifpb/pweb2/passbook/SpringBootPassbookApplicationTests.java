package br.edu.ifpb.pweb2.passbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPassbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
